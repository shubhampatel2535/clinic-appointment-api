const mongoose = require('mongoose');
const request = require('supertest');
const { MongoMemoryServer } = require('mongodb-memory-server');
const app = require('../src/app');
const Slot = require('../src/models/Slot');

let mongo;

beforeAll(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri());
});

afterEach(async () => {
  await Slot.deleteMany({});
});

afterAll(async () => {
  await mongoose.disconnect();
  if (mongo) await mongo.stop();
});

async function createSlot(overrides = {}) {
  const startAt = new Date(Date.now() + 60 * 60 * 1000);
  const response = await request(app).post('/api/slots').send({
    clinicName: 'Northside Clinic',
    doctorName: 'Dr. Rao',
    startAt: startAt.toISOString(),
    endAt: new Date(startAt.getTime() + 30 * 60 * 1000).toISOString(),
    ...overrides
  });
  expect(response.status).toBe(201);
  return response.body.data;
}

const patient = { patientName: 'Asha Patel', patientEmail: 'asha@example.com' };

describe('Clinic appointment booking rules', () => {
  test('creates and lists available slots', async () => {
    const slot = await createSlot();
    const response = await request(app).get('/api/slots?status=available');
    expect(response.status).toBe(200);
    expect(response.body.count).toBe(1);
    expect(response.body.data[0]._id).toBe(slot._id);
  });

  test('rejects invalid slot input', async () => {
    const response = await request(app).post('/api/slots').send({
      clinicName: 'Clinic', doctorName: 'Doctor',
      startAt: 'not-a-date', endAt: 'also-not-a-date'
    });
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe('VALIDATION_ERROR');
  });

  test('books a slot and rejects a second booking', async () => {
    const slot = await createSlot();
    const first = await request(app).post('/api/bookings').send({ slotId: slot._id, ...patient });
    expect(first.status).toBe(201);
    const second = await request(app).post('/api/bookings').send({
      slotId: slot._id, patientName: 'Ravi Kumar', patientEmail: 'ravi@example.com'
    });
    expect(second.status).toBe(409);
    expect(second.body.error.code).toBe('SLOT_UNAVAILABLE');
  });

  test('only one simultaneous booking request succeeds', async () => {
    const slot = await createSlot();
    const attempts = await Promise.all([
      request(app).post('/api/bookings').send({ slotId: slot._id, ...patient }),
      request(app).post('/api/bookings').send({ slotId: slot._id, patientName: 'Ravi Kumar', patientEmail: 'ravi@example.com' })
    ]);
    expect(attempts.filter((r) => r.status === 201)).toHaveLength(1);
    expect(attempts.filter((r) => r.status === 409)).toHaveLength(1);
    const saved = await Slot.findById(slot._id).lean();
    expect(saved.status).toBe('booked');
    expect(saved.booking).not.toBeNull();
  });

  test('cancels a booking and allows the slot to be booked again', async () => {
    const slot = await createSlot();
    const booked = await request(app).post('/api/bookings').send({ slotId: slot._id, ...patient });
    const bookingId = booked.body.data.bookingId;
    const cancelled = await request(app).delete(`/api/bookings/${bookingId}`);
    expect(cancelled.status).toBe(200);
    expect(cancelled.body.data.status).toBe('available');
    const rebook = await request(app).post('/api/bookings').send({ slotId: slot._id, patientName: 'Ravi Kumar', patientEmail: 'ravi@example.com' });
    expect(rebook.status).toBe(201);
  });

  test('cannot cancel a booked slot directly', async () => {
    const slot = await createSlot();
    await request(app).post('/api/bookings').send({ slotId: slot._id, ...patient });
    const response = await request(app).delete(`/api/slots/${slot._id}`);
    expect(response.status).toBe(409);
    expect(response.body.error.code).toBe('SLOT_NOT_CANCELLABLE');
  });

  test('returns 404 for a missing slot', async () => {
    const response = await request(app).post('/api/bookings').send({
      slotId: new mongoose.Types.ObjectId().toString(), ...patient
    });
    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe('SLOT_NOT_FOUND');
  });

  test('validates patient email', async () => {
    const slot = await createSlot();
    const response = await request(app).post('/api/bookings').send({
      slotId: slot._id, patientName: 'Asha', patientEmail: 'invalid'
    });
    expect(response.status).toBe(400);
  });
});
