const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function parseDate(value) {
  if (typeof value !== 'string' || value.trim() === '') return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function validateSlotInput(body) {
  const errors = [];
  if (!isNonEmptyString(body.clinicName)) errors.push('clinicName is required and must be a non-empty string.');
  if (!isNonEmptyString(body.doctorName)) errors.push('doctorName is required and must be a non-empty string.');
  const startAt = parseDate(body.startAt);
  const endAt = parseDate(body.endAt);
  if (!startAt) errors.push('startAt must be a valid ISO-8601 date/time.');
  if (!endAt) errors.push('endAt must be a valid ISO-8601 date/time.');
  if (startAt && endAt && endAt <= startAt) errors.push('endAt must be later than startAt.');
  if (startAt && startAt <= new Date()) errors.push('startAt must be in the future.');
  return { errors, value: { clinicName: body.clinicName?.trim(), doctorName: body.doctorName?.trim(), startAt, endAt } };
}

function validateBookingInput(body) {
  const errors = [];
  if (!isNonEmptyString(body.patientName)) errors.push('patientName is required and must be a non-empty string.');
  if (!isNonEmptyString(body.patientEmail) || !EMAIL_RE.test(body.patientEmail.trim())) {
    errors.push('patientEmail must be a valid email address.');
  }
  return {
    errors,
    value: {
      patientName: body.patientName?.trim(),
      patientEmail: body.patientEmail?.trim().toLowerCase()
    }
  };
}

module.exports = { validateSlotInput, validateBookingInput };
