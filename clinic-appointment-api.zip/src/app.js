const express = require('express');
const slotRoutes = require('./routes/slots');
const bookingRoutes = require('./routes/bookings');
const { notFound, errorHandler } = require('./middleware/errors');

const app = express();
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.status(200).json({ status: 'ok' }));
app.use('/api/slots', slotRoutes);
app.use('/api/bookings', bookingRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
