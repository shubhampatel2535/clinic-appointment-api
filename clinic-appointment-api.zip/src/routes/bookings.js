const express = require('express');
const mongoose = require('mongoose');
const { randomUUID } = require('crypto');
const Slot = require('../models/Slot');
const { validateBookingInput } = require('../utils/validation');

const router = express.Router();

// POST /api/bookings - body: { slotId, patientName, patientEmail }
router.post('/', async (req, res, next) => {
  try {
    const body = req.body || {};
    if (typeof body.slotId !== 'string' || !mongoose.isValidObjectId(body.slotId)) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'slotId must be a valid identifier.' } });
    }
    const { errors, value } = validateBookingInput(body);
    if (errors.length) return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Invalid booking data.', details: errors } });

    const bookingId = randomUUID();
    const booking = { bookingId, ...value, bookedAt: new Date() };

    // Critical concurrency guarantee: the status predicate and update happen atomically in MongoDB.
    const slot = await Slot.findOneAndUpdate(
      { _id: body.slotId, status: 'available' },
      { $set: { status: 'booked', booking } },
      { new: true, runValidators: true }
    );

    if (slot) return res.status(201).json({ data: { bookingId, slotId: slot._id, patientName: value.patientName, patientEmail: value.patientEmail, bookedAt: slot.booking.bookedAt, slot } });

    const existing = await Slot.findById(body.slotId).lean();
    if (!existing) return res.status(404).json({ error: { code: 'SLOT_NOT_FOUND', message: 'Slot not found.' } });
    if (existing.status === 'cancelled') return res.status(409).json({ error: { code: 'SLOT_CANCELLED', message: 'This slot has been cancelled and cannot be booked.' } });
    return res.status(409).json({ error: { code: 'SLOT_UNAVAILABLE', message: 'This slot is already booked.' } });
  } catch (err) { return next(err); }
});

// GET /api/bookings/:bookingId - find a booking by its public UUID.
router.get('/:bookingId', async (req, res, next) => {
  try {
    const slot = await Slot.findOne({ 'booking.bookingId': req.params.bookingId }).lean();
    if (!slot) return res.status(404).json({ error: { code: 'BOOKING_NOT_FOUND', message: 'Booking not found or already cancelled.' } });
    return res.status(200).json({ data: { bookingId: slot.booking.bookingId, slotId: slot._id, patientName: slot.booking.patientName, patientEmail: slot.booking.patientEmail, bookedAt: slot.booking.bookedAt, slot } });
  } catch (err) { return next(err); }
});

// DELETE /api/bookings/:bookingId - cancel booking and make slot available again.
router.delete('/:bookingId', async (req, res, next) => {
  try {
    const slot = await Slot.findOneAndUpdate(
      { 'booking.bookingId': req.params.bookingId, status: 'booked' },
      { $set: { status: 'available', booking: null } },
      { new: true, runValidators: true }
    );
    if (!slot) {
      const alreadyCancelled = await Slot.exists({ _id: { $exists: true }, 'booking.bookingId': req.params.bookingId });
      if (alreadyCancelled) return res.status(409).json({ error: { code: 'BOOKING_NOT_ACTIVE', message: 'This booking is not active.' } });
      return res.status(404).json({ error: { code: 'BOOKING_NOT_FOUND', message: 'Booking not found or already cancelled.' } });
    }
    return res.status(200).json({ data: { slotId: slot._id, status: slot.status }, message: 'Booking cancelled. The slot is available again.' });
  } catch (err) { return next(err); }
});

module.exports = router;
