const express = require('express');
const mongoose = require('mongoose');
const Slot = require('../models/Slot');
const { validateSlotInput } = require('../utils/validation');

const router = express.Router();

// POST /api/slots - create a new appointment slot.
router.post('/', async (req, res, next) => {
  try {
    const { errors, value } = validateSlotInput(req.body || {});
    if (errors.length) return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Invalid slot data.', details: errors } });
    const slot = await Slot.create(value);
    return res.status(201).json({ data: slot });
  } catch (err) { return next(err); }
});

// GET /api/slots?status=available&clinicName=... - list slots.
router.get('/', async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.status !== undefined) {
      if (!['available', 'booked', 'cancelled'].includes(req.query.status)) {
        return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'status must be available, booked, or cancelled.' } });
      }
      filter.status = req.query.status;
    }
    if (req.query.clinicName !== undefined) {
      if (typeof req.query.clinicName !== 'string' || !req.query.clinicName.trim()) {
        return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'clinicName must be a non-empty string.' } });
      }
      filter.clinicName = new RegExp(escapeRegex(req.query.clinicName.trim()), 'i');
    }
    const slots = await Slot.find(filter).sort({ startAt: 1 }).lean();
    return res.status(200).json({ data: slots, count: slots.length });
  } catch (err) { return next(err); }
});

// GET /api/slots/:slotId - get one slot.
router.get('/:slotId', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.slotId)) return res.status(400).json({ error: { code: 'INVALID_ID', message: 'slotId must be a valid identifier.' } });
    const slot = await Slot.findById(req.params.slotId).lean();
    if (!slot) return res.status(404).json({ error: { code: 'SLOT_NOT_FOUND', message: 'Slot not found.' } });
    return res.status(200).json({ data: slot });
  } catch (err) { return next(err); }
});

// DELETE /api/slots/:slotId - cancel a slot, only if not booked.
router.delete('/:slotId', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.slotId)) return res.status(400).json({ error: { code: 'INVALID_ID', message: 'slotId must be a valid identifier.' } });
    const slot = await Slot.findOneAndUpdate(
      { _id: req.params.slotId, status: 'available' },
      { $set: { status: 'cancelled' } },
      { new: true, runValidators: true }
    );
    if (slot) return res.status(200).json({ data: slot, message: 'Slot cancelled.' });
    const existing = await Slot.findById(req.params.slotId).lean();
    if (!existing) return res.status(404).json({ error: { code: 'SLOT_NOT_FOUND', message: 'Slot not found.' } });
    return res.status(409).json({ error: { code: 'SLOT_NOT_CANCELLABLE', message: 'Only an available slot can be cancelled. Cancel its booking first if applicable.' } });
  } catch (err) { return next(err); }
});

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = router;
