require('dotenv').config();
const mongoose = require('mongoose');
const app = require('./app');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;

async function start() {
  if (!MONGODB_URI) {
    throw new Error('MONGODB_URI is required. Copy .env.example to .env and configure it.');
  }
  await mongoose.connect(MONGODB_URI);
  app.listen(PORT, () => console.log(`Clinic Appointment API listening on port ${PORT}`));
}

start().catch((error) => {
  console.error('Failed to start API:', error.message);
  process.exit(1);
});
