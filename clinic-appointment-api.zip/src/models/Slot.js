const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  bookingId: { type: String, required: true },
  patientName: { type: String, required: true, trim: true },
  patientEmail: { type: String, required: true, lowercase: true, trim: true },
  bookedAt: { type: Date, required: true, default: Date.now }
}, { _id: false });

const slotSchema = new mongoose.Schema({
  clinicName: { type: String, required: true, trim: true },
  doctorName: { type: String, required: true, trim: true },
  startAt: { type: Date, required: true },
  endAt: { type: Date, required: true },
  status: { type: String, enum: ['available', 'booked', 'cancelled'], default: 'available', required: true },
  booking: { type: bookingSchema, default: null }
}, { timestamps: true });

slotSchema.index({ status: 1, startAt: 1 });
slotSchema.index({ 'booking.bookingId': 1 }, { sparse: true });

module.exports = mongoose.model('Slot', slotSchema);
